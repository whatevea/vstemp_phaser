import gameConfig from "./scripts/config.js";
const game = new Phaser.Game(gameConfig);


//global 


//default style
window.textStyle= {
    fontFamily: 'Offside',
    fontSize: '64px'
};
